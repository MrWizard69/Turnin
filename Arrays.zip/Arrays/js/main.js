var muppetNames = ["Kermit", "Miss Piggy", "Gonzo"]; // 0, 1, 2, 3

console.log(muppetNames[0]);

muppetNames[1] = "Rizzo";

console.log(muppetNames[1]);
