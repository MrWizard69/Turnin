// Basic Function Structure and Function Invocation

function outptMsg(){
    console.log("Hello World!");
}

function calcArea(){
    var width = 20;
    var height = 30;
    var area = width * height;

    console.log(area);
}

outptMsg();
calcArea();
// end

// Variable Scope

var width = 5;
console.log(width);

//end

//Arguments and Parameters

function dogYears(age){
    var dogYears = age * 7;
    console.log("Sparky is " + dogYears + " in dog years");
}

//end

//Returning Values

function calcArea(w, h){
    var area = w * h;
    return area;
}

var total = calcArea(30, 20);

console.log(total);

//end

// Anonymous Functions

var calcArea = function(w, h){
    var area = w * h;
    return area;
}

var a = calcArea(20, 30);

console.log(a);



