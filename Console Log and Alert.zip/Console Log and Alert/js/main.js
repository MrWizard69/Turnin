var yearBorn = 1990;

console.log("Hello!");
console.log(yearBorn);

alert("Hello! :D");
