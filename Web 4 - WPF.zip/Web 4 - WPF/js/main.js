// Functions

function helloMsg(){
    console.log("Hello World! :D");
}

function status(){
    console.log("Looks like I\'ll be using a boilerplate this time...");
}

function whtThe(){
    console.log("What the F???");
}

helloMsg();
status();
whtThe();