var width = 4;
var height = 5;
var area = width * height / 2;

console.log(area);
