var orangeBins = [234, 567, 833];
var total = orangeBins[0] + orangeBins[1] + orangeBins[2];

console.log(total);
