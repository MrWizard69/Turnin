/**
 * Created with JetBrains WebStorm.
 * User: jordanwilson
 * Date: 7/22/13
 * Time: 1:25 PM
 * To change this template use File | Settings | File Templates.
 */

//Conditional Example

var oldEnough = true;

if(oldEnough){
    console.log("You can ride the coaster!");
}
console.log("What comes next?");

//Relational Expressions

var kidHeight = 30;
var minHeight = 48;

if(kidHeight > minHeight){
    console.log("You can ride the coaster!");
}

//Condition with Expression

var kidHeight1 = 47;
var minHeight1 = 48;

if(kidHeight1 > minHeight1){
    console.log("You can ride the coaster!");
}

//If and Else

var kidHeight2 = 47;
var minHeight2 = 48;

if(kidHeight2 > minHeight2){
    console.log("You can ride the coaster!");
}

else{
    console.log("Sorry kid, you gots some growing to do...");
}

//else If

var kidHeight3 = 47;
var minHeight3 = 48;
var wParentHeight = 45;

if(kidHeight3 > minHeight3){
    console.log("You can ride the coaster!");
}

else if(kidHeight3 > wParentHeight){
    console.log("You can ride but only with a parent");
}

else{
    console.log("Sorry kid, you gots some growing to do...");
}

//Logical Operators

var budget = 300;
var iPhonePrice = 199.99;
var paycheck = 200;
var wonLottery = true;

if(iPhonePrice < budget && paycheck > 300 || wonLottery){
    console.log("We can buy the phone! :D");
}
else{
    console.log("No! No mi gusta!");
}

//Ternary Operators

var gpa = 48;

if(gpa > 2.0){
    console.log("You can graduate!");
}
else{
    console.log("GPA is too low!");
}

(gpa > 2.0) ? console.log("You can graduate!") : console.log("GPA is too low!");




