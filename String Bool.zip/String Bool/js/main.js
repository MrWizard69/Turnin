var age = 38;
var isStudent = false;
var firstName = "Jordan";
var phrase = "I don\'t know, \n you\'ll have to ask.";

console.log(phrase);
