var a = 3;

a = a + 4;
//a += 4
//a *= 4
//a /= 4
//a -= 4
//a ++
//a --

console.log(a);
