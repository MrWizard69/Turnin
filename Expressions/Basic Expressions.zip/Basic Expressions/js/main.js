var a = 2;
var b;

b = a + 3;
console.log(a);
