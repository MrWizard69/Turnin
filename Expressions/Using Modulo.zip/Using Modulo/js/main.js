var remainder1 = 32 / 10;

console.log(remainder1);

var remainder2 = 32 % 10;

console.log(remainder2);
