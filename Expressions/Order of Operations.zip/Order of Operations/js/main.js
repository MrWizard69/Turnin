var quiz1 = 87;
var quiz2 = 100;
var quiz3 = 60;
var quiz4 = 80;
var average = (quiz1 + quiz2 + quiz3 + quiz4) / 4;

console.log(average);

var length = 7;
var width = 6;
var perimeter = length * 2 + width * 2;

console.log(perimeter);
