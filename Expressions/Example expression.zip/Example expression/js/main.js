var yearBorn = 1974;
var age = 2013 - yearBorn;
console.log(age);
