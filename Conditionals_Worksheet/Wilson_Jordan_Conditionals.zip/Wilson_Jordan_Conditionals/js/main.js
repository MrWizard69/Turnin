// Jordan Wilson
// 07/22/13
// Conditional Worksheet

// Temp Converter

var temp = prompt("What is the temperature outside?"); //asks what the temp is
var celfar = prompt("is that in Fahrenheit or Celsius? F = 1 or C = 0"); // figures out if your temperature is in F or C

if(celfar == 1){
    alert("If we were to convert that to celsius, it would be " + (temp - 32) * 5/9); // If the temp was in F, it converts it to C
}
else if(celfar == 0){
    alert("If we were to convert that to fahrenheit, it would be " + (temp * 1.8 + 32)); //If the the temp was in C it converts it to F
}
else{
    alert("Umm..What was that??"); // if you type anything else, you will get this message
}
// end

// Grade Letter Calculator

var grade = prompt("What is your grade percent in a class?"); // asks what your grade is

if(grade >= 95){
    alert("You got a A+!"); // if your grade is 95 - 100
}
else if(grade > 89 && grade < 95){
    alert("You got an A!"); // if your grade is 90 - 94
}
else if(grade > 84 && grade < 90){
    alert("You got a B+!");  // if your grade is 85 - 89
}
else if(grade > 79 && grade < 85){
    alert("You got a B!");  // if your grade is 80 - 84
}
else if(grade > 75 && grade < 80){
    alert("You got a C+!"); // if your grade is 75 - 79
}
else if(grade > 69 && grade < 75){
    alert("You got a C!");   // if your grade is 70 - 74
}
else if(grade < 70){
    alert("You are failing as a student and as a person!!!"); // if your grade is below a 70
}
// end

// Tire Pressure

var tireArray = [30, 30, 35, 35]; // the first two are the front tires and the last two are the back tires.

if(tireArray[0] == tireArray[1]){
    alert("Your front tires are great!");// if your front tires match
}
else{
    alert("I would have your front tires checked out"); // if they don't
}

if(tireArray[2] == tireArray[3]){
    alert("And your back tires look great!"); // if your back tires match
}
else{
    alert("But I would have your back tires looked at tho");// if they don't
}
