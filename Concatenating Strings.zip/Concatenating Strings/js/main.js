var firstName = "Jordan";
var lastName = "Wilson";
var fullName = firstName + " " + lastName;

console.log(fullName);

var a = "6";
var b = "6";
var result = a + b;

console.log(result);
