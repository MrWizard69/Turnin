// Jordan Wilson
// Dog Years

var sparkyYears = prompt("Say you have a dog named Sparky. How old is he in people years?"); // a prompt to ask the user a question

alert("Sparky is "+ sparkyYears * 7 + " in dog years!"); // a message that calculates Sparky's human years to dog years

//---------------- end

// Slice of Pie I

var numOfPeople = prompt("So you finally got invited to a party! :D When you arrive, everyone there is hungry \n and elects you to order and buy the pizza... :[ How many people are at the party?"); // Asks how many people are at the party
var numOfSlices = prompt("So how many slices will each pizza have?"); //asks how many slices each pizza will have
var numOfPizza = prompt("How many pizza's do you want to buy?"); //asks how many pizza's to order
var slicesPerPerson = (numOfSlices * numOfPizza) / numOfPeople; // calculates how many slices each person will have

alert("Every person would get " + Math.floor(slicesPerPerson) + " slices of pizza! :D"); //displays how many slices each person will have.

//-------------- end

//Slice of Pie II

var sparkysCut = (numOfSlices * numOfPizza) % numOfPeople; //calculates how many left over slices Sparky will get

alert("Sparky stole " + sparkysCut + " slices of Pizza!"); // displays how many left over slices Sparky will get

//------------- end

// Average Shopping Bill
var arr = [100, 50, 80, 40, 60]; // an array of numbers or shopping bills
alert("For week one, your shopping bill was $100, week two was $50, week three was $80, week four was $40 and week five was $60"); //tells what's in the array
alert("Your average shopping bill is " + "$" + (arr[0] + arr[1] + arr[2] + arr[3] + arr[4]) / 5);  // calcs the average

//-------------- end

// Discounts

var stuff = prompt("So I have given you a list of stuff... stuffs1 and stuffs2... What do you want? type 1 or 2"); // gives you a list of stuffs
var discount1 = .20; // 20% off
var discount2 = .10; // 10% off
var stuffs1 = 10; // the price of stuffs1
var stuffs2 = 50;// the price of stuffs2
var stuffs1disc = stuffs1 * discount1; // calculates the discounted price of stuffs1
var stuffs2disc = stuffs2 * discount2; // calculates the discounted price of stuffs2
var tax1 = (stuffs1 - stuffs1disc) * .07; // calculates the tax of stuffs1
var tax2 = (stuffs2 - stuffs2disc) * .07; // calculates the tax of stuffs2


if(stuff == 1){
    alert("You picked stuffs1! Great choice! The stuff in this bunch is specifically unspecific but costs $" + stuffs1); //if user picks 1
    alert("Lucky you! There is a special on this item. It is currently 20% off!");  //the discount
    alert("You are saving $" + stuffs1disc);  //savings
    alert("and your new total before taxes is $" + (stuffs1 - stuffs1disc)); //total before taxes
    alert("With taxes, stuffs1 will cost $" + (tax1 + (stuffs1 - stuffs1disc))); //total after taxes
}
else if(stuff == 2){
    alert("You picked stuffs2! Wonderful! :D In my opinion, the specifically unspecific things in this bunch are better than stuffs1 but costs $" + stuffs2);//if user picks 2
    alert("Lucky you! There is a special on this item. It is currently 10% off!"); // the discount
    alert("You are saving $" + stuffs2disc);  //savings
    alert("and your new total before taxes is $" + (stuffs2 - stuffs2disc)); //total before taxes
    alert("With taxes, stuffs1 will cost $" + (tax2 + (stuffs2 - stuffs2disc))); //total after taxes
}
else{
    alert("Fine! You get nothing! refresh the page!");//if the user picks anything else
}




