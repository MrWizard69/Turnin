//Jordan Wilson
// 7-30-13
// Functions Worksheet


//Circumference

var circ = prompt("To calculate the circumference of a circle, tell me the diameter in inches?"); //the prompt for 'd' in circumf function

function circumf(d){
    var circumference = Math.ceil(d * Math.PI);// the formula
    return circumference; //returning the answer
}

var circumference = circumf(circ); // a variable to link to the circumf function

console.log("The circumference is " + circumference +" inches"); // printing out the final result

//end

//Stung!

var victimLbs = prompt("If you were to get stung to death by a bunch of bees, it's good to know how many it would take! How many pounds are you?"); //the prompt for 'lbs' in the stung function

function stung(lbs){
    var bees = Math.ceil(8.666666667 * lbs); // to calculate how many stings a victim could take based on their weight in pounds
    return bees; //returns the equation
}

var beeMenace = stung(victimLbs); //assigns the beeMenace variable to the stung function

console.log("You can take a whopping " + beeMenace + " stings!"); // displays how many stings a victim could take

//end
